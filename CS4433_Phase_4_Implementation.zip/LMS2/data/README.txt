Runtime database files and submitted attachments are stored here. This directory is not included in public source control.
